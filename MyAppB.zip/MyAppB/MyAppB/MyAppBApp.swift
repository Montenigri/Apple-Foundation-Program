//
//  MyAppBApp.swift
//  MyAppB
//
//  Created by angelo galante on 23/06/25.
//

import SwiftUI

@main
struct MyAppBApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
